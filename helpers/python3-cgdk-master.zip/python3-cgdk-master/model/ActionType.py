class ActionType:
    NONE = 0
    STAFF = 1
    MAGIC_MISSILE = 2
    FROST_BOLT = 3
    FIREBALL = 4
    HASTE = 5
    SHIELD = 6
