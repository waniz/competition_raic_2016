class ProjectileType:
    MAGIC_MISSILE = 0
    FROST_BOLT = 1
    FIREBALL = 2
    DART = 3
