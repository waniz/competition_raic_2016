class MinionType:
    ORC_WOODCUTTER = 0
    FETISH_BLOWDART = 1
