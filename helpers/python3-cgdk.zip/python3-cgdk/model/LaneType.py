class LaneType:
    TOP = 0
    MIDDLE = 1
    BOTTOM = 2
